const dashboard = [
    {
        name: 'Dashboard',
        link: '/dashboard',
    },
    {
        name: 'Cadastros',
        link: '/cadastros'
    },
    {
        name: 'Solicitações',
        link: '/solicitacoes'
    },
    {
        name: 'Consultas',
        link: '/consultas'
    },
    {
        name: 'Relatórios',
        link: '/relatorios'
    },
    {
        name: 'Configurações',
        link: '/configuracoes'
    }
];

export default dashboard
<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
body {
  background-color: #f1f1f1 !important;
  box-sizing: border-box;
}

.slide-fade-enter-active {
  transition: all 0.2s ease;
}
.slide-fade-leave-active {
  transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
}
.slide-fade-enter,
.slide-fade-leave-to {
  transform: translateX(10px);
  opacity: 0;
}
</style>
